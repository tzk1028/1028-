/*******************************************************************************
 * main.c  —  周期信号测量分析装置
 *   模式: 直流 -> 交流 -> 波形 -> 直流 (PB0 按键循环切换)
 *   显示: 0.96" OLED (SSD1306, 软件I2C PB6/PB7)
 ******************************************************************************/
#include "stm32f10x.h"
#include "Delay.h"
#include "Key.h"
#include "OLED.h"
#include "AD.h"
#include "config.h"

typedef enum { MODE_DC = 0, MODE_AC, MODE_WAVE, MODE_COUNT } mode_t;

static mode_t g_mode = MODE_DC;

/* 波形显示用的纵向平滑量程, 切换模式/无信号时清零 */
static u16 g_wave_span = 0;

/* 频率显示: 最近 3 次测量取中值, 抑制单次跳变 */
static float g_freq_hist[3] = {0.0f, 0.0f, 0.0f};

static float freq_median(float f)
{
    float a, b, c, t;

    if (g_freq_hist[2] <= 0.0f) {
        g_freq_hist[0] = g_freq_hist[1] = g_freq_hist[2] = f;
    } else {
        g_freq_hist[0] = g_freq_hist[1];
        g_freq_hist[1] = g_freq_hist[2];
        g_freq_hist[2] = f;
    }

    a = g_freq_hist[0];
    b = g_freq_hist[1];
    c = g_freq_hist[2];
    if (a > b) { t = a; a = b; b = t; }
    if (b > c) { b = c; }
    if (a > b) { b = a; }
    return b;
}

static u8 char_w(u8 font)
{
    return (font == OLED_FONT_6X8) ? 6 : 8;
}

/* 显示电压, 例 " 2.500V" */
static void show_voltage(u8 x, u8 y, float v, u8 font)
{
    u8 w = char_w(font);
    OLED_ShowFloat(x, y, v, 1, 3, font, 0);
    OLED_ShowString(x + 6 * w, y, "V", font, 0);
}

/* 显示频率, 自动 kHz / Hz */
static void show_freq(u8 x, u8 y, float f, u8 font)
{
    u8 w = char_w(font);
    if (f >= 1000.0f) {
        OLED_ShowFloat(x, y, f / 1000.0f, 2, 2, font, 0);
        OLED_ShowString(x + 6 * w, y, "kHz", font, 0);
    } else {
        OLED_ShowFloat(x, y, f, 3, 0, font, 0);
        OLED_ShowString(x + 4 * w, y, "Hz", font, 0);
    }
}

/*----------------------------- 直流 --------------------------------------*/
static void show_dc(void)
{
    float v = 0.0f;
    u8 ok = Measure_DC(&v);

    OLED_Clear();
    OLED_ShowString(0, 0,  "DC MODE", OLED_FONT_8X16, 0);
    if (ok == 0u) {
        OLED_ShowString(0, 16, "V=", OLED_FONT_8X16, 0);
        show_voltage(16, 16, v, OLED_FONT_8X16);
    } else {
        OLED_ShowString(0, 16, "ADC TIMEOUT", OLED_FONT_8X16, 0);
    }
    OLED_ShowString(0, 32, "-5.00~+5.00V", OLED_FONT_8X16, 0);
    OLED_ShowString(0, 48, "VDD=", OLED_FONT_8X16, 0);
    show_voltage(32, 48, AD_GetVDDA(), OLED_FONT_8X16);
    OLED_Refresh();
}

/*----------------------------- 交流 --------------------------------------*/
static void show_ac(void)
{
    float vpp, freq;

    OLED_Clear();
    OLED_ShowString(0, 0, "AC MODE", OLED_FONT_8X16, 0);

    if (Measure_AC(&vpp, &freq) == 0) {
        OLED_ShowString(0, 16, "Vpp=", OLED_FONT_8X16, 0);
        show_voltage(32, 16, vpp, OLED_FONT_8X16);

        OLED_ShowString(0, 32, "F=", OLED_FONT_8X16, 0);
        show_freq(16, 32, freq_median(freq), OLED_FONT_8X16);

        OLED_ShowString(0, 48, "100Hz~20kHz", OLED_FONT_8X16, 0);
    } else {
        g_freq_hist[0] = g_freq_hist[1] = g_freq_hist[2] = 0.0f;
        OLED_ShowString(0, 24, "NO SIGNAL", OLED_FONT_8X16, 0);
    }
    OLED_Refresh();
}

/*----------------------------- 波形 --------------------------------------*/
static void plot_waveform(float freq)
{
    u32 fs, spp, n, start = 0;
    u16 maxv = 0, minv = 4095, mid, span, h, lo, hi, i;
    u8 prev_y = 0xFF, below = 0, x;

    if (freq <= 0.0f) return;             /* 防除零 */

    fs  = AD_GetSampleRate();
    spp = fs / (u32)freq;                 /* 每周期采样点数 */
    if (spp < 1u) spp = 1u;
    n = spp * 2u;                         /* 显示 2 个周期 */
    if (n > ADC_BUF_LEN) n = ADC_BUF_LEN;
    if (n < 2u) n = 2u;

    for (i = 0; i < ADC_BUF_LEN; i++) {
        if (ADC_Buf[i] > maxv) maxv = ADC_Buf[i];
        if (ADC_Buf[i] < minv) minv = ADC_Buf[i];
    }
    if (maxv <= minv) return;

    /* 带迟滞的上升沿触发: 抑制噪声导致的起点抖动 */
    mid = (u16)((maxv + minv) >> 1);
    h   = (u16)((maxv - minv) >> 3);
    lo  = (u16)(mid - h);
    hi  = (u16)(mid + h);
    for (i = 1; (u32)i + n <= ADC_BUF_LEN; i++) {
        if (ADC_Buf[i] < lo) {
            below = 1;
        } else if (below && ADC_Buf[i] > hi) {
            start = i;
            break;
        }
    }

    /* 纵向自动增益: 增大立即跟上, 减小缓慢过渡, 避免逐帧"呼吸" */
    span = (u16)(maxv - minv);
    if (span < 1u) span = 1u;
    if (span >= g_wave_span) {
        g_wave_span = span;
    } else {
        u16 ns = (u16)(((u32)g_wave_span * 7u + span) / 8u);
        g_wave_span = (ns < 1u) ? 1u : ns;
    }

    for (x = 0; x < 128; x++) {
        u32 idx = start + (u32)x * n / 128u;
        u16 v   = ADC_Buf[idx];
        u8  y   = 30 - (u8)((u32)(v - minv) * 29 / g_wave_span);

        OLED_DrawPoint(x, y, 1);
        if (prev_y != 0xFF) {
            u8 a = prev_y, b = y, t;
            if (a > b) { t = a; a = b; b = t; }
            for (t = a; t <= b; t++) OLED_DrawPoint(x, t, 1);
        }
        prev_y = y;
    }
}

static void show_wave(void)
{
    float vpp, freq;

    OLED_Clear();

    if (Measure_Wave(&vpp, &freq) == 0) {
        plot_waveform(freq);

        OLED_ShowString(0, 32, "Vpp=", OLED_FONT_8X16, 0);
        show_voltage(32, 32, vpp, OLED_FONT_8X16);

        OLED_ShowString(0, 48, "F=", OLED_FONT_8X16, 0);
        show_freq(16, 48, freq_median(freq), OLED_FONT_8X16);
    } else {
        g_wave_span = 0;
        g_freq_hist[0] = g_freq_hist[1] = g_freq_hist[2] = 0.0f;
        OLED_ShowString(0, 24, "NO SIGNAL", OLED_FONT_8X16, 0);
    }
    OLED_Refresh();
}

/*----------------------------------------------------------------------
 * 未使用引脚 -> 模拟输入(AIN)
 *   AIN 会关闭施密特输入触发器: 引脚不悬空自激、不拾取/注入噪声,
 *   且不驱动、不翻转, 不会给 ADC 前端和电源带来干扰。
 *
 * 刻意跳过(绝不改动, 以免影响功能/调试):
 *   PA0        ADC 信号输入
 *   PA13/PA14  SWD 下载调试(改了就无法再次烧写)
 *   PA15/PB3/PB4  JTAG(默认带内部上下拉, 保持原状)
 *   PB0        按键
 *   PB6/PB7    OLED I2C
 *   PC13/14/15 RTC / 32.768kHz 晶振
 *   PD0/PD1    8MHz 主晶振
 *--------------------------------------------------------------------*/
static void GPIO_UnusedPins_Init(void)
{
    GPIO_InitTypeDef gpio;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB, ENABLE);

    gpio.GPIO_Mode  = GPIO_Mode_AIN;
    gpio.GPIO_Speed = GPIO_Speed_2MHz;

    /* PA1 ~ PA12 */
    gpio.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 |
                    GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 |
                    GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12;
    GPIO_Init(GPIOA, &gpio);

    /* PB1, PB2, PB5, PB8 ~ PB15 */
    gpio.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_5 |
                    GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11 |
                    GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
    GPIO_Init(GPIOB, &gpio);
}

/* 轮询按键: 先立即检查; 未按下则等待一个刷新周期, 期间每 10ms 复查,
 * 避免主循环较长时漏掉"快按"。返回 1 表示模式键按下。 */
static u8 Key_WaitAndScan(void)
{
    u16 t;

    if (Key_Scan() == 1) return 1;

    for (t = 0; t < (u16)(DISPLAY_REFRESH_MS / 10u); t++) {
        Delay_ms(10);
        if (Key_Scan() == 1) return 1;
    }
    return 0;
}

/*----------------------------- 主函数 ------------------------------------*/
int main(void)
{
    Key_Init();
    OLED_Init();
    AD_Init();
    GPIO_UnusedPins_Init();       /* 在功能引脚之后执行, 不覆盖已用引脚 */

    OLED_Clear();
    OLED_ShowString(0, 24, "START...", OLED_FONT_8X16, 0);
    OLED_Refresh();
    Delay_ms(800);

    while (1) {
        if (Key_WaitAndScan()) {
            g_mode = (mode_t)((g_mode + 1) % MODE_COUNT);
            g_wave_span = 0;          /* 切换模式后重新建立纵向量程 */
            g_freq_hist[0] = g_freq_hist[1] = g_freq_hist[2] = 0.0f;
            OLED_Clear();
            OLED_Refresh();
            Delay_ms(SETTLE_MS);
        }

        switch (g_mode) {
            case MODE_DC:   show_dc();   break;
            case MODE_AC:   show_ac();   break;
            case MODE_WAVE: show_wave(); break;
            default:        g_mode = MODE_DC; break;
        }
    }
}

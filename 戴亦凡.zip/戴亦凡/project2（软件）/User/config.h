#ifndef __CONFIG_H
#define __CONFIG_H

#include "sys.h"

/*==============================================================================
 * 硬件引脚 (已从 EasyEDA 工程网表核对)
 *   ADC : PA0 (ADC1_IN0)
 *   按键: PB0 (低电平有效)
 *   OLED: SCL=PB6, SDA=PB7
 *============================================================================*/

/* ---- OLED (软件 I2C) ---- */
#define OLED_I2C_PORT          GPIOB
#define OLED_I2C_RCC           RCC_APB2Periph_GPIOB
#define OLED_SCL_PIN           GPIO_Pin_6
#define OLED_SDA_PIN           GPIO_Pin_7

/* ---- 按键 ---- */
#define KEY_PORT               GPIOB
#define KEY_RCC                RCC_APB2Periph_GPIOB
#define KEY_PIN                GPIO_Pin_0

/* ---- 信号输入 ---- */
#define ADC_IN_PORT            GPIOA
#define ADC_IN_PIN             GPIO_Pin_0

/* ---- 采样 ---- */
#define ADC_BUF_LEN            2048u
/* ADC 采样时间 28.5 周期(总转换 3.42us). 采样率上限取 200kHz,
 * 给转换留 1.6us 余量, 避免偶发溢出; 20kHz 信号仍有 10 点/周期 */
#define SAMPLE_RATE_MAX        200000u
#define SAMPLE_RATE_MIN        2000u

/* 有效信号最小峰峰值(ADC 码值), 低于此判为无信号/纯噪声.
 * 100mVpp 输入 -> ADC 约 41 码; 取 20 码(约 50mVpp 输入)作门槛 */
#define ADC_MIN_SPAN           20u

/*==============================================================================
 * 模拟前端标定 —— 直接按原理图电阻计算, 不再用经验值
 *
 *   LM358 双运放:
 *     通道1: 跟随器, 产生中点偏置  V_bias = VCC33 * R5/(R5+R6)
 *     通道2: 求和放大,
 *        V_out = (1+R8/R4) * (V_bias/R7 + V_sig/R9) / (1/R3 + 1/R7 + 1/R9)
 *
 *   两种常见前端量程, 用 FRONTEND_33V 选择(按你实板电阻填):
 *     =0  -5V~+5V -> 0~3.3V :  R8/R4=1, R5=R6   => V_out=1.652+0.3324*Vin
 *     =1  -3.3V~+3.3V -> 0~3.3V: R8/R4=2, R5:R6=1:2 => V_out=1.650+0.4987*Vin
 *
 *   ★ 电阻值必须与你实板一致! 若不同, 直接改下面的宏, CAL 会自动重算。
 *============================================================================*/
#define FRONTEND_33V           0             /* 0=±5V前端; 1=±3.3V前端 */

#define V_CC33                 3.18f         /* 3.3V 轨实测值(万用表量得 3.18V) */

#define R3_OHM                 49900.0f      /* 49.9k */
#define R7_OHM                 33200.0f      /* 33.2k */
#define R9_OHM                100000.0f      /* 100k  */
#define R4_OHM                 10000.0f      /* 反馈下臂 */
#define R5_OHM                 10000.0f      /* 偏置分压下臂 */

#if FRONTEND_33V
  #define R8_OHM               20000.0f      /* R8/R4=2 => 总增益 0.5 */
  #define R6_OHM               20000.0f      /* R5:R6=1:2 => V_bias=1.10V */
#else
  #define R8_OHM               10000.0f      /* R8/R4=1 => 总增益 0.33 */
  #define R6_OHM               10000.0f      /* R5=R6    => V_bias=1.65V */
#endif

/* ADC 参考(VDDA) = 3.3V 轨, 固定值 */
/* ADC 基准(VDDA)与前端偏置取自同一路 3.3V 轨, 统一用 V_CC33 */
#define ADC_VREF               V_CC33

/* 由电阻推导 */
#define G_SUM                  (1.0f/R3_OHM + 1.0f/R7_OHM + 1.0f/R9_OHM)
#define AMP_GAIN               (1.0f + R8_OHM/R4_OHM)
#define SIG_GAIN               (AMP_GAIN * (1.0f/R9_OHM) / G_SUM)
#define BIAS_GAIN              (AMP_GAIN * (1.0f/R7_OHM) / G_SUM)
#define V_BIAS                 (V_CC33 * R5_OHM / (R5_OHM + R6_OHM))

/* 反算: V_sig = (ADC/4096*ADC_VREF) * CAL_GAIN + CAL_OFFSET
 * R4/R8/R5/R6 全为 10k 时: CAL_GAIN=3.0081, CAL_OFFSET=-4.9699 (满量程 ±4.96V) */
#define CAL_GAIN               (1.0f / SIG_GAIN)
#define CAL_OFFSET             (-V_BIAS * BIAS_GAIN / SIG_GAIN)
#define CAL_VPP_GAIN           (1.0f / SIG_GAIN)

/* 交流峰峰值算法: 1 = RMS 法(仅正弦, 抗噪声)
 *                 0 = 最大最小法(正弦/方波/三角波都适用) */
#define VPP_USE_RMS            0

/* 零点修正(V): 把输入短路到 GND, 读到的值取反填这里.
 * 实测短路读 -0.047V -> 填 +0.047f; 读 +0.012V -> 填 -0.012f.
 * 只影响直流读数, 不影响峰峰值(交流) */
#define CAL_OFFSET_TRIM        0.035f

/* ---- 刷新 / 稳定 ---- */
#define DISPLAY_REFRESH_MS     150u
#define SETTLE_MS              120u

#endif

# 周期信号测量分析装置 —— Keil5 工程（可直接编译）

本工程由你原有的 `led` 工程骨架搭建（沿用其中的标准外设库 Library/ 与 Start/），
**已在本机 Keil MDK 5.24（ARMCC V5.06）实际编译通过：0 Error / 0 Warning**。

## 一、打开与编译

1. 双击 **`projeck.uvprojx`** 用 Keil5 打开。
2. 直接点 **Build (F7)** —— 应显示 `0 Error(s), 0 Warning(s)`。
3. 点 **Download (F8)** 通过 ST-Link 下载到板子；也可直接烧写 `Objects\projeck.hex`。

> 工程已生成 `Objects\projeck.axf` 和 `Objects\projeck.hex`，可直接下载。

## 二、引脚（已从硬件网表核对）

| 功能 | 引脚 |
|------|------|
| 信号输入 ADC | **PA0**（ADC1_IN0） |
| 模式按键 | **PB0**（低有效，内部上拉） |
| OLED SCL | **PB6** |
| OLED SDA | **PB7** |

## 三、操作

- 上电 OLED 显示 `START...`，随后进入 **直流模式**。
- 按 **PB0** 循环切换：直流 → 交流 → 波形 → 直流。
- 直流显示电压；交流显示 Vpp 与频率；波形模式上半屏显示 2 个周期波形，下方显示 Vpp 与频率。

## 四、标定（重要）

默认按 **LM358 前端把 -5V~+5V 映射到 0~3.3V** 设置，见 `User/config.h`：

```c
#define CAL_GAIN     (10.0f/3.3f)   // ≈3.03
#define CAL_OFFSET   (-5.0f)
#define CAL_VPP_GAIN (10.0f/3.3f)
```

若你实测发现前端是 **±3.3V 量程**（增益 0.5、偏置 1.65V），改成：

```c
#define CAL_GAIN      2.0f
#define CAL_OFFSET    (-3.3f)
#define CAL_VPP_GAIN  2.0f
```

标定方法：直流模式分别输入已知 -5V / 0V / +5V，微调 `CAL_GAIN`、`CAL_OFFSET` 使显示与万用表一致。

## 五、文件说明

```
projeck.uvprojx      Keil5 工程文件（双击打开）
Hardware/
  AD.c / AD.h        ADC+DMA+TIM3 采样，直流/交流/波形测量
  Key.c / Key.h      按键扫描（PB0）
  OLED.c / OLED.h    SSD1306 软件I2C驱动（含帧缓冲）
  OLED_Font.h        6x8 / 8x16 ASCII 字库
  LED.c / LED.h      保留（本程序未使用）
System/
  Delay.c / Delay.h  延时（Delay_us / Delay_ms）
User/
  main.c             主程序：模式状态机 + 显示
  config.h           引脚与标定参数
  sys.h              类型定义
Library/             标准外设库（原有，未改动）
Start/               CMSIS + 启动文件（原有）
```

## 六、未使用引脚处理（防干扰）

`main.c` 中的 `GPIO_UnusedPins_Init()` 把未用引脚统一设为 **模拟输入 (AIN)**：

- AIN 会关闭引脚的施密特输入触发器 → 引脚不会悬空自激、不会拾取噪声，也不会向 ADC 前端或电源注入干扰；
- 只配置、不驱动、不翻转，上电后引脚电平恒定，**不会产生开关噪声**。

**刻意跳过、绝不改动的引脚**（避免影响功能或下载调试）：

| 引脚 | 原因 |
|------|------|
| PA0 | ADC 信号输入 |
| PA13 / PA14 | SWD 下载调试（改了会无法再次烧写）|
| PA15 / PB3 / PB4 | JTAG（默认带内部上下拉，保持原状最稳）|
| PB0 | 按键 |
| PB6 / PB7 | OLED I2C |
| PC13/14/15 | RTC / 32.768kHz 晶振 |
| PD0 / PD1 | 8MHz 主晶振 |

## 七、常见问题

- **OLED 不亮**：确认模块 I2C 地址为 `0x78`；少数模块为 `0x7A`，改 `Hardware/OLED.h` 的 `OLED_ADDR`。
- **显示方向反了**：把 `OLED.c` 初始化里的 `0xC8` 改为 `0xC0`、`0xA1` 改为 `0xA0`。
- **频率/幅值偏差大**：先按第四节标定前端增益与偏置。
- **工程宏**：已在 `Options → C/C++ → Define` 中设置 `USE_STDPERIPH_DRIVER,STM32F10X_MD`，编译确定无告警。

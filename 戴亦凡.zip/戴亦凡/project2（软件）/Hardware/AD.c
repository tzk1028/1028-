/*******************************************************************************
 * AD.c  —  ADC 采样 + 直流/交流/波形测量
 *   PA0 (ADC1_IN0) 输入, TIM3 更新事件触发 ADC, DMA1 通道1 搬运
 ******************************************************************************/
#include "stm32f10x.h"
#include <math.h>
#include "Delay.h"
#include "AD.h"

volatile u16 ADC_Buf[ADC_BUF_LEN];

static u32   cur_fs = 100000;
static float g_vdda = V_CC33;      /* 实时 VDDA, 由内部基准 VREFINT 跟踪 */
static u16   g_vref_anchor = 0;    /* 首次读到的 VREFINT 码值, 作为 V_CC33 的锚点 */

static u8 adc_read_vdda(void);

/* ADC 码值 -> 电压 (V): 用实时 VDDA, 零点(偏置)随 VDDA 一起变, 再加实测零点修正.
 * 偏置和 ADC 基准同源, 所以电源波动时分子分母同步变化, 读数不受影响 */
static float adc_to_voltage(float adc)
{
    float v_out = adc / 4096.0f * g_vdda;
    float v_zero = g_vdda * (R5_OHM / (R5_OHM + R6_OHM)) * BIAS_GAIN;
    return (v_out - v_zero) * CAL_GAIN + CAL_OFFSET_TRIM;
}

float AD_GetVDDA(void)
{
    return g_vdda;
}

/* 用内部基准 VREFINT 实时跟踪 3.3V 轨.
 * 内部基准的绝对值有 ±1~3% 的个体误差, 直接用 1.20V 反算会整体偏移,
 * 所以这里改成"比例跟踪": 第一次读到的码值锚定为 V_CC33(万用表实测值),
 * 之后只跟踪码值的相对变化, 再平滑、限幅后使用.
 * 返回 0=跟踪中, 1=本次读取失败(沿用上次值). */
static u8 adc_read_vdda(void)
{
    u16 i, v, acc = 0, n = 0;
    volatile u32 to;

    TIM_Cmd(TIM3, DISABLE);
    DMA_Cmd(DMA1_Channel1, DISABLE);
    ADC_DMACmd(ADC1, DISABLE);

    ADC_TempSensorVrefintCmd(ENABLE);        /* 置 TSVREFE, 通道17 才接通 */
    Delay_us(100);                           /* 等内部基准稳定 */
    ADC_InjectedChannelConfig(ADC1, ADC_Channel_17, 1, ADC_SampleTime_239Cycles5);
    ADC_InjectedSequencerLengthConfig(ADC1, 1);

    /* 连读 5 次: 丢第 1 次, 后 4 次取平均, 保证基准已建立 */
    for (i = 0; i < 5u; i++) {
        ADC_ClearFlag(ADC1, ADC_FLAG_JEOC);
        ADC_SoftwareStartInjectedConvCmd(ADC1, ENABLE);
        to = 0;
        while (!ADC_GetFlagStatus(ADC1, ADC_FLAG_JEOC)) {
            if (++to > 200000u) break;
        }
        if (ADC_GetFlagStatus(ADC1, ADC_FLAG_JEOC) == RESET) break;
        v = (u16)ADC_GetInjectedConversionValue(ADC1, ADC_InjectedChannel_1);
        ADC_ClearFlag(ADC1, ADC_FLAG_JEOC);
        if (i == 0u) continue;
        acc += v;
        n++;
    }

    ADC_TempSensorVrefintCmd(DISABLE);
    ADC_DMACmd(ADC1, ENABLE);

    if (n < 2u || acc == 0u) return 1;

    v = (u16)(acc / n);
    if (v == 0u) return 1;

    if (g_vref_anchor == 0u) {
        g_vref_anchor = v;                   /* 首次: 锚定为 V_CC33 */
        g_vdda = V_CC33;
        return 0;
    }

    {
        float nv = V_CC33 * (float)g_vref_anchor / (float)v;
        if (nv < 3.00f) nv = 3.00f;
        if (nv > 3.40f) nv = 3.40f;
        g_vdda = g_vdda * 0.85f + nv * 0.15f;  /* 平滑, 单次噪声不跳 */
    }
    return 0;
}

void AD_Init(void)
{
    GPIO_InitTypeDef        gpio;
    ADC_InitTypeDef         adc;
    DMA_InitTypeDef         dma;
    TIM_TimeBaseInitTypeDef tim;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_ADC1, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
    RCC_ADCCLKConfig(RCC_PCLK2_Div6);          /* 12MHz */

    gpio.GPIO_Pin   = ADC_IN_PIN;
    gpio.GPIO_Mode  = GPIO_Mode_AIN;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(ADC_IN_PORT, &gpio);

    adc.ADC_Mode               = ADC_Mode_Independent;
    adc.ADC_ScanConvMode       = DISABLE;
    adc.ADC_ContinuousConvMode = DISABLE;
    adc.ADC_ExternalTrigConv   = ADC_ExternalTrigConv_T3_TRGO;
    adc.ADC_DataAlign          = ADC_DataAlign_Right;
    adc.ADC_NbrOfChannel       = 1;
    ADC_Init(ADC1, &adc);

    /* 采样时间 28.5 周期: LM358 带 ADC 采样电容负载时建立较慢,
     * 7.5 周期(0.625us)不足以建立, 会采到"毛刺"造成波形噪声;
     * 28.5+12.5=41 周期 @12MHz ≈ 3.42us, 上限约 250kHz, 覆盖 20kHz 足够 */
    ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 1, ADC_SampleTime_28Cycles5);

    ADC_DMACmd(ADC1, ENABLE);
    ADC_ExternalTrigConvCmd(ADC1, ENABLE);
    ADC_Cmd(ADC1, ENABLE);

    ADC_ResetCalibration(ADC1);
    while (ADC_GetResetCalibrationStatus(ADC1));
    ADC_StartCalibration(ADC1);
    while (ADC_GetCalibrationStatus(ADC1));

    tim.TIM_Prescaler         = 0;
    tim.TIM_CounterMode       = TIM_CounterMode_Up;
    tim.TIM_Period            = 71;
    tim.TIM_ClockDivision     = TIM_CKD_DIV1;
    tim.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM3, &tim);
    TIM_SelectOutputTrigger(TIM3, TIM_TRGOSource_Update);
    TIM_Cmd(TIM3, DISABLE);

    dma.DMA_PeripheralBaseAddr = (u32)&ADC1->DR;
    dma.DMA_MemoryBaseAddr     = (u32)ADC_Buf;
    dma.DMA_DIR                = DMA_DIR_PeripheralSRC;
    dma.DMA_BufferSize         = ADC_BUF_LEN;
    dma.DMA_PeripheralInc      = DMA_PeripheralInc_Disable;
    dma.DMA_MemoryInc          = DMA_MemoryInc_Enable;
    dma.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
    dma.DMA_MemoryDataSize     = DMA_MemoryDataSize_HalfWord;
    dma.DMA_Mode               = DMA_Mode_Normal;
    dma.DMA_Priority           = DMA_Priority_High;
    dma.DMA_M2M                = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel1, &dma);
    DMA_Cmd(DMA1_Channel1, DISABLE);
}

void AD_SetSampleRate(u32 fs)
{
    u32 arr;

    if (fs > SAMPLE_RATE_MAX) fs = SAMPLE_RATE_MAX;
    if (fs < SAMPLE_RATE_MIN) fs = SAMPLE_RATE_MIN;

    arr = SystemCoreClock / fs - 1u;
    if (arr < 14) arr = 14;
    if (arr > 65535) arr = 65535;

    TIM_Cmd(TIM3, DISABLE);
    /* 改采样率时先关掉 ADC 外部触发, 避免 EGR 产生的这次更新触发一次
     * "野转换", 该转换的旧数据会被 DMA 当成第 1 点, 把波形量程拉坏 */
    ADC_ExternalTrigConvCmd(ADC1, DISABLE);
    TIM3->PSC = 0;
    TIM3->ARR = arr;
    TIM3->EGR = TIM_PSCReloadMode_Immediate;
    TIM_SetCounter(TIM3, 0);

    cur_fs = SystemCoreClock / (arr + 1u);
}

u32 AD_GetSampleRate(void)
{
    return cur_fs;
}

/* 启动一次 DMA 采集. 返回 0=完成, 1=超时(缓冲不可信, 上层应丢弃) */
u8 AD_Capture(void)
{
    volatile u32 timeout = 0;
    u8 ok;

    DMA_Cmd(DMA1_Channel1, DISABLE);
    DMA1_Channel1->CMAR  = (u32)ADC_Buf;
    DMA1_Channel1->CNDTR = ADC_BUF_LEN;
    DMA_ClearFlag(DMA1_FLAG_TC1);
    DMA_Cmd(DMA1_Channel1, ENABLE);

    /* 丢掉可能残留的 EOC 请求, 再打外部触发, 保证第 1 点就是新数据 */
    ADC_ClearFlag(ADC1, ADC_FLAG_EOC);
    ADC_ExternalTrigConvCmd(ADC1, ENABLE);

    TIM_SetCounter(TIM3, 0);
    TIM_Cmd(TIM3, ENABLE);

    while (!DMA_GetFlagStatus(DMA1_FLAG_TC1)) {
        if (++timeout > 0xFFFFFF) break;
    }
    TIM_Cmd(TIM3, DISABLE);

    ok = (DMA_GetFlagStatus(DMA1_FLAG_TC1) != RESET) ? 0u : 1u;
    return ok;
}

/*---------------------------- 测量 ---------------------------------------*/

/* 3 点中值滤波: 去掉采样缓冲中的孤立毛刺(ADC 偶尔被干扰) */
static void filter_buf(void)
{
    u16 i, a, b, c, m;

    a = ADC_Buf[0];
    for (i = 1; i < ADC_BUF_LEN - 1u; i++) {
        b = ADC_Buf[i];
        c = ADC_Buf[i + 1];

        if ((a <= b && b <= c) || (c <= b && b <= a)) {
            m = b;
        } else if ((b <= a && a <= c) || (c <= a && a <= b)) {
            m = a;
        } else {
            m = c;
        }
        ADC_Buf[i] = m;
        a = b;
    }
}

u8 Measure_DC(float *v)
{
    u32 sum = 0;
    u16 i;

    adc_read_vdda();                    /* 先实时测一次 3.3V(VDDA) */

    /* 51200Hz x 2048 点 = 40ms, 正好 2 个 50Hz 工频周期, 抑制工频串扰 */
    AD_SetSampleRate(51200);
    if (AD_Capture() != 0u) return 1;   /* 超时: 缓冲不可信, 不上报 */

    for (i = 0; i < ADC_BUF_LEN; i++)
        sum += ADC_Buf[i];

    *v = adc_to_voltage((float)sum / (float)ADC_BUF_LEN);
    return 0;
}

/* 鲁棒极值: 先用 256 桶直方图剔除上下各 1% 的孤立尖峰, 再在剩余范围内
 * 找真实极值. 对正弦/方波/三角波都适用, 且不受采样毛刺影响 */
static void robust_minmax(u16 *pmin, u16 *pmax)
{
    static u16 hist[256];
    u16 b, i, lo_bin, hi_bin, lo, hi, mn, mx;
    u32 cum, nth;

    for (b = 0; b < 256; b++) hist[b] = 0;
    for (i = 0; i < ADC_BUF_LEN; i++) hist[ADC_Buf[i] >> 4]++;

    nth = (u32)ADC_BUF_LEN / 100u;      /* 1% 样本数 */
    if (nth < 1u) nth = 1u;

    cum = 0; lo_bin = 0;
    for (b = 0; b < 256; b++) {
        cum += hist[b];
        if (cum >= nth) { lo_bin = b; break; }
    }

    cum = 0; hi_bin = 255;
    for (b = 255; ; b--) {
        cum += hist[b];
        if (cum >= nth) { hi_bin = b; break; }
        if (b == 0) { hi_bin = 0; break; }
    }

    lo = (u16)(lo_bin << 4);
    hi = (u16)((hi_bin << 4) | 0x0Fu);

    mn = 4095; mx = 0;
    for (i = 0; i < ADC_BUF_LEN; i++) {
        u16 v = ADC_Buf[i];
        if (v >= lo && v <= hi) {
            if (v < mn) mn = v;
            if (v > mx) mx = v;
        }
    }
    if (mn > mx) { mn = 0; mx = 4095; }

    *pmin = mn;
    *pmax = mx;
}

int Measure_AC(float *vpp, float *freq)
{
    u32 fs = SAMPLE_RATE_MAX;
    int attempt;

    adc_read_vdda();                    /* 先实时测一次 3.3V(VDDA) */

    for (attempt = 0; attempt < 8; attempt++) {
        u16 maxv = 0, minv = 4095, mid, h;
        u16 first = 0xFFFF, last = 0;
        u16 count = 0, i;
        u8  below = 0;
        u32 actual;
        u16 a, b, c, f;

        AD_SetSampleRate(fs);
        actual = AD_GetSampleRate();      /* 实际采样率(可能被限幅) */
        if (AD_Capture() != 0u) { fs >>= 2; continue; }   /* 超时: 丢弃本次 */
        robust_minmax(&minv, &maxv);

        /* 幅度门槛: 峰峰值 < ADC_MIN_SPAN 视为无信号(纯噪声) */
        if ((u16)(maxv - minv) >= ADC_MIN_SPAN) {
            mid = (u16)((maxv + minv) >> 1);
            h   = (u16)((maxv - minv) >> 3);        /* 迟滞带 = 1/8 峰峰值 */

            /* 先做 3 点滑动平均, 再带迟滞找上升过零点:
             * 抑制噪声引起的多计/漏计, 使频率读数稳定 */
            a = ADC_Buf[0];
            b = ADC_Buf[1];
            for (i = 2; i < ADC_BUF_LEN; i++) {
                c = ADC_Buf[i];
                f = (u16)(((u32)a + b + c) / 3u);

                if (f < (u16)(mid - h)) {
                    below = 1;
                } else if (below && f > (u16)(mid + h)) {
                    below = 0;
                    if (first == 0xFFFF) first = (u16)(i - 1);
                    last = (u16)(i - 1);
                    count++;
                }
                a = b;
                b = c;
            }

            if (count >= 2) {
                u16 periods = count - 1;
                u32 samples = (u32)(last - first);

                *freq = (float)actual * (float)periods / (float)samples;

#if VPP_USE_RMS
                /* 正弦信号的峰峰值用 RMS 法: Vpp = 2√2·RMS.
                 * 噪声只以方差形式进入, 不会像 max-min 那样被峰值直接顶大 */
                {
                    u32 sum = 0;
                    u16 k;
                    float mean, sumsq = 0.0f, d, rms;

                    for (k = 0; k < ADC_BUF_LEN; k++)
                        sum += ADC_Buf[k];
                    mean = (float)sum / (float)ADC_BUF_LEN;
                    for (k = 0; k < ADC_BUF_LEN; k++) {
                        d = (float)ADC_Buf[k] - mean;
                        sumsq += d * d;
                    }
                    rms = sqrtf(sumsq / (float)ADC_BUF_LEN);
                    *vpp = 2.8284271f * rms / 4096.0f * g_vdda * CAL_VPP_GAIN;
                }
#else
                *vpp = (float)(maxv - minv) / 4096.0f * g_vdda * CAL_VPP_GAIN;
#endif
                return 0;
            }
        }

        fs >>= 2;
    }
    return -1;
}

int Measure_Wave(float *vpp, float *freq)
{
    u32 fs;
    u16 maxv = 0, minv = 4095;

    if (Measure_AC(vpp, freq) != 0)
        return -1;

    fs = (u32)(*freq * 60.0f);
    AD_SetSampleRate(fs);
    if (AD_Capture() != 0u) return -1;      /* 超时: 不上报 */
    robust_minmax(&minv, &maxv);
    *vpp = (float)(maxv - minv) / 4096.0f * g_vdda * CAL_VPP_GAIN;
    filter_buf();              /* 只在显示前滤波, 不影响 Vpp 计算 */

    return 0;
}

#include "stm32f10x.h"
#include "Delay.h"
#include "OLED.h"
#include "OLED_Font.h"

/* 显存 128x64/8 = 1024 字节 */
static u8 OLED_GRAM[128][8];

#define SCL_H()  GPIO_SetBits(OLED_I2C_PORT, OLED_SCL_PIN)
#define SCL_L()  GPIO_ResetBits(OLED_I2C_PORT, OLED_SCL_PIN)
#define SDA_H()  GPIO_SetBits(OLED_I2C_PORT, OLED_SDA_PIN)
#define SDA_L()  GPIO_ResetBits(OLED_I2C_PORT, OLED_SDA_PIN)

static void IIC_Start(void)
{
    SDA_H(); SCL_H(); Delay_us(4);
    SDA_L(); Delay_us(4);
    SCL_L();
}

static void IIC_Stop(void)
{
    SDA_L(); SCL_H(); Delay_us(4);
    SDA_H(); Delay_us(4);
}

/* 应答处理:
 *   OLED_STRICT_ACK=1: 释放 SDA 后读 ACK, 统计 NACK, 错误过多放弃本帧;
 *   OLED_STRICT_ACK=0: 兼容模式 —— 第 9 个时钟直接拉低 SDA, 不检测 ACK.
 * 本模块是推挽驱动, 内部上拉很弱(~40k), 读 ACK 的上升沿可能不到位,
 * 会被误判成 NACK 导致刷新被放弃; 屏显示异常时先用 0 排除干扰. */
#define OLED_STRICT_ACK   0

static u8 IIC_WaitAck(void)
{
#if OLED_STRICT_ACK
    GPIO_InitTypeDef gpio;
    u8 ack;

    /* 释放 SDA, 让从机能把它拉低 (推挽直接写高会和从机抢线) */
    gpio.GPIO_Pin   = OLED_SDA_PIN;
    gpio.GPIO_Mode  = GPIO_Mode_IPU;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(OLED_I2C_PORT, &gpio);

    Delay_us(5);
    SCL_H();
    Delay_us(5);
    ack = GPIO_ReadInputDataBit(OLED_I2C_PORT, OLED_SDA_PIN);
    SCL_L();
    Delay_us(2);

    /* 恢复推挽输出, 释放为高 */
    gpio.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(OLED_I2C_PORT, &gpio);
    SDA_H();
    Delay_us(2);

    return (ack == Bit_RESET) ? 0u : 1u;
#else
    /* 兼容模式: 直接拉低 SDA 打第 9 个时钟, 不检测应答 */
    SDA_L();
    Delay_us(2);
    SCL_H();
    Delay_us(2);
    SCL_L();
    return 0u;
#endif
}

static u8 IIC_WriteByte(u8 byte)
{
    u8 i;
    for (i = 0; i < 8; i++) {
        SCL_L();
        if (byte & 0x80) SDA_H(); else SDA_L();
        Delay_us(2);
        SCL_H();
        Delay_us(2);
        byte <<= 1;
    }
    SCL_L();
    return IIC_WaitAck();
}

static u8 OLED_WriteCmd(u8 cmd)
{
    IIC_Start();
    if (IIC_WriteByte(OLED_ADDR)) { IIC_Stop(); return 1u; }
    if (IIC_WriteByte(0x00))      { IIC_Stop(); return 1u; }
    if (IIC_WriteByte(cmd))       { IIC_Stop(); return 1u; }
    IIC_Stop();
    return 0u;
}

void OLED_Init(void)
{
    GPIO_InitTypeDef gpio;

    RCC_APB2PeriphClockCmd(OLED_I2C_RCC, ENABLE);

    gpio.GPIO_Pin   = OLED_SCL_PIN | OLED_SDA_PIN;
    gpio.GPIO_Mode  = GPIO_Mode_Out_PP;      /* 推挽输出 */
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(OLED_I2C_PORT, &gpio);

    SCL_H();
    SDA_H();

    OLED_WriteCmd(0xAE);
    OLED_WriteCmd(0x20); OLED_WriteCmd(0x02);
    OLED_WriteCmd(0xB0);
    OLED_WriteCmd(0xC8);
    OLED_WriteCmd(0x00);
    OLED_WriteCmd(0x10);
    OLED_WriteCmd(0x40);
    OLED_WriteCmd(0x81); OLED_WriteCmd(0xFF);
    OLED_WriteCmd(0xA1);
    OLED_WriteCmd(0xA6);
    OLED_WriteCmd(0xA8); OLED_WriteCmd(0x3F);
    OLED_WriteCmd(0xA4);
    OLED_WriteCmd(0xD3); OLED_WriteCmd(0x00);
    OLED_WriteCmd(0xD5); OLED_WriteCmd(0x80);
    OLED_WriteCmd(0xD9); OLED_WriteCmd(0xF1);
    OLED_WriteCmd(0xDA); OLED_WriteCmd(0x12);
    OLED_WriteCmd(0xDB); OLED_WriteCmd(0x40);
    OLED_WriteCmd(0x8D); OLED_WriteCmd(0x14);
    OLED_WriteCmd(0xAF);

    OLED_Clear();
    OLED_Refresh();
}

void OLED_Clear(void)
{
    u8 x, y;
    for (x = 0; x < 128; x++)
        for (y = 0; y < 8; y++)
            OLED_GRAM[x][y] = 0x00;
}

void OLED_DrawPoint(u8 x, u8 y, u8 t)
{
    u8 page, bit;
    if (x > 127 || y > 63) return;
    page = y >> 3;
    bit  = y & 0x07;
    if (t) OLED_GRAM[x][page] |=  (1 << bit);
    else   OLED_GRAM[x][page] &= ~(1 << bit);
}

u8 OLED_Refresh(void)
{
    u8 i, n, err = 0;

    for (i = 0; i < 8; i++) {
        if (OLED_WriteCmd(0xB0 + i)) err++;
        if (OLED_WriteCmd(0x00))     err++;
        if (OLED_WriteCmd(0x10))     err++;

        IIC_Start();
        if (IIC_WriteByte(OLED_ADDR)) { IIC_Stop(); err++; continue; }
        if (IIC_WriteByte(0x40))      { IIC_Stop(); err++; continue; }
        for (n = 0; n < 128; n++) {
            if (IIC_WriteByte(OLED_GRAM[n][i])) err++;
        }
        IIC_Stop();

        if (err > 8u) break;          /* 总线异常, 放弃本次刷新 */
    }
    return (err == 0u) ? 0u : 1u;     /* 0=全部 ACK, 1=出现过 NACK */
}

void OLED_ShowChar(u8 x, u8 y, u8 chr, u8 font, u8 mode)
{
    const u8 *p;
    u8 w, h, r, c, bits;

    if (chr < 32 || chr > 126) chr = 32;

    if (font == OLED_FONT_6X8) {
        w = 6; h = 8;  p = oled_asc2_6x8[chr - 32];
    } else {
        w = 8; h = 16; p = oled_asc2_8x16[chr - 32];
    }

    for (r = 0; r < h; r++) {
        bits = p[r];
        for (c = 0; c < w; c++) {
            if (bits & (1 << c)) OLED_DrawPoint(x + c, y + r, 1);
            else if (mode)       OLED_DrawPoint(x + c, y + r, 0);
        }
    }
}

void OLED_ShowString(u8 x, u8 y, const char *str, u8 font, u8 mode)
{
    u8 w = (font == OLED_FONT_6X8) ? 6 : 8;
    while (*str) {
        if (x > 127) break;
        OLED_ShowChar(x, y, (u8)*str, font, mode);
        x += w;
        str++;
    }
}

void OLED_ShowNum(u8 x, u8 y, u32 num, u8 len, u8 font, u8 mode)
{
    u8 i, j;
    u8 w = (font == OLED_FONT_6X8) ? 6 : 8;
    u8 buf[12];

    for (i = 0; i < len; i++) {
        buf[len - 1 - i] = '0' + (u8)(num % 10);
        num /= 10;
    }
    for (j = 0; j + 1 < len; j++) {
        if (buf[j] != '0') break;
        buf[j] = ' ';
    }
    for (i = 0; i < len; i++) {
        OLED_ShowChar(x, y, buf[i], font, mode);
        x += w;
    }
}

void OLED_ShowSignedNum(u8 x, u8 y, s32 num, u8 len, u8 font, u8 mode)
{
    u8 w = (font == OLED_FONT_6X8) ? 6 : 8;
    if (num < 0) {
        OLED_ShowChar(x, y, '-', font, mode);
        num = -num;
    } else {
        OLED_ShowChar(x, y, ' ', font, mode);
    }
    OLED_ShowNum(x + w, y, (u32)num, len, font, mode);
}

void OLED_ShowFloat(u8 x, u8 y, float num, u8 intlen, u8 declen, u8 font, u8 mode)
{
    u8 w = (font == OLED_FONT_6X8) ? 6 : 8;
    u8 i, neg = 0;
    u32 factor = 1, integer, decimal;
    u8 dbuf[8];

    if (num < 0) { neg = 1; num = -num; }
    for (i = 0; i < declen; i++) factor *= 10;

    integer = (u32)num;
    decimal = (u32)((num - (float)integer) * factor + 0.5f);
    if (decimal >= factor) { decimal = 0; integer++; }

    if (neg) { OLED_ShowChar(x, y, '-', font, mode); x += w; }
    else     { OLED_ShowChar(x, y, ' ', font, mode); x += w; }

    OLED_ShowNum(x, y, integer, intlen, font, mode);
    x += intlen * w;

    if (declen) {
        OLED_ShowChar(x, y, '.', font, mode);
        x += w;
        for (i = 0; i < declen; i++) {
            dbuf[declen - 1 - i] = '0' + (u8)(decimal % 10);
            decimal /= 10;
        }
        for (i = 0; i < declen; i++) {
            OLED_ShowChar(x, y, dbuf[i], font, mode);
            x += w;
        }
    }
}

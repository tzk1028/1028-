#ifndef __OLED_H
#define __OLED_H

#include "sys.h"
#include "config.h"

#define OLED_ADDR        0x78      /* 若模块为 0x7A 请修改 */

#define OLED_FONT_6X8    0
#define OLED_FONT_8X16   1

void OLED_Init(void);
void OLED_Clear(void);
u8   OLED_Refresh(void);          /* 0=全部 ACK, 1=出现过 NACK */
void OLED_DrawPoint(u8 x, u8 y, u8 t);
void OLED_ShowChar(u8 x, u8 y, u8 chr, u8 font, u8 mode);
void OLED_ShowString(u8 x, u8 y, const char *str, u8 font, u8 mode);
void OLED_ShowNum(u8 x, u8 y, u32 num, u8 len, u8 font, u8 mode);
void OLED_ShowSignedNum(u8 x, u8 y, s32 num, u8 len, u8 font, u8 mode);
void OLED_ShowFloat(u8 x, u8 y, float num, u8 intlen, u8 declen, u8 font, u8 mode);

#endif

#ifndef __AD_H
#define __AD_H

#include "sys.h"
#include "config.h"

extern volatile u16 ADC_Buf[ADC_BUF_LEN];

void     AD_Init(void);
void     AD_SetSampleRate(u32 fs);
u32      AD_GetSampleRate(void);
u8       AD_Capture(void);          /* 0=完成, 1=DMA 超时(缓冲不可信) */
float    AD_GetVDDA(void);          /* 最近一次实时反算出的 3.3V(VDDA) */

u8    Measure_DC(float *v);         /* 0=成功, 1=采集失败 */
int   Measure_AC(float *vpp, float *freq);
int   Measure_Wave(float *vpp, float *freq);

#endif

#ifndef __Key_H
#define __Key_H

#include "sys.h"
#include "config.h"

void Key_Init(void);
u8   Key_Scan(void);      /* 返回 1 = 模式键按下 */

#endif

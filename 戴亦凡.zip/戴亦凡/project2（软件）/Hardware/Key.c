#include "stm32f10x.h"
#include "Delay.h"
#include "Key.h"

void Key_Init(void)
{
    GPIO_InitTypeDef gpio;

    RCC_APB2PeriphClockCmd(KEY_RCC, ENABLE);

    gpio.GPIO_Pin   = KEY_PIN;
    gpio.GPIO_Mode  = GPIO_Mode_IPU;      /* 上拉输入, 按下为低 */
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(KEY_PORT, &gpio);
}

u8 Key_Scan(void)
{
    static u8 key_up = 1;

    if (GPIO_ReadInputDataBit(KEY_PORT, KEY_PIN) == 0) {
        if (key_up) {
            Delay_ms(10);
            if (GPIO_ReadInputDataBit(KEY_PORT, KEY_PIN) == 0) {
                key_up = 0;
                return 1;
            }
        }
    } else {
        key_up = 1;
    }
    return 0;
}

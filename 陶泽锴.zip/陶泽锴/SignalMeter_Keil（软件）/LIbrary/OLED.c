#include "stm32f10x.h"
#include "OLED.h"
#include "OLED_Font.h"
#include "app_config.h"
#include "timing.h"

#define OLED_WIDTH 128u
#define OLED_HEIGHT 64u
#define OLED_SCL_HIGH() GPIO_SetBits(GPIOB, OLED_SCL_PIN)
#define OLED_SCL_LOW() GPIO_ResetBits(GPIOB, OLED_SCL_PIN)
#define OLED_SDA_HIGH() GPIO_SetBits(GPIOB, OLED_SDA_PIN)
#define OLED_SDA_LOW() GPIO_ResetBits(GPIOB, OLED_SDA_PIN)
static uint8_t screen[OLED_WIDTH * OLED_HEIGHT / 8u];
static volatile uint8_t oled_error;

uint8_t OLED_GetLastError(void) { return oled_error; }

static uint8_t OLED_ClockHigh(void)
{
    OLED_SCL_HIGH();
#if !OLED_PUSH_PULL
    {
        uint16_t timeout = 0u;
        while (!GPIO_ReadInputDataBit(GPIOB, OLED_SCL_PIN))
        {
            if (++timeout >= 100u) { oled_error = 2u; return 0u; }
            Timing_DelayUs(1u);
        }
    }
#endif
    return 1u;
}

static uint8_t OLED_I2C_Start(void)
{
    OLED_SDA_HIGH();
    if (!OLED_ClockHigh()) return 0u;
    Timing_DelayUs(5u);
    OLED_SDA_LOW();
    Timing_DelayUs(5u);
    OLED_SCL_LOW();
    return 1u;
}

static void OLED_I2C_Stop(void)
{
    OLED_SCL_LOW();
    OLED_SDA_LOW();
    Timing_DelayUs(5u);
    (void)OLED_ClockHigh();
    Timing_DelayUs(5u);
    OLED_SDA_HIGH();
    Timing_DelayUs(5u);
}

static uint8_t OLED_I2C_SendByte(uint8_t value)
{
    uint8_t bit, ack;
#if OLED_PUSH_PULL
    GPIO_InitTypeDef gpio;
#endif
    for (bit = 0u; bit < 8u; ++bit)
    {
        OLED_SCL_LOW();
        if (value & 0x80u) OLED_SDA_HIGH(); else OLED_SDA_LOW();
        Timing_DelayUs(5u);
        if (!OLED_ClockHigh()) return 0u;
        Timing_DelayUs(5u);
        value <<= 1;
    }
    OLED_SCL_LOW();
#if OLED_PUSH_PULL
    /* Release the bus for the receiver's ACK, even in compatibility mode. */
    gpio.GPIO_Pin = OLED_SDA_PIN;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    gpio.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOB, &gpio);
#else
    OLED_SDA_HIGH();
#endif
    Timing_DelayUs(5u);
    ack = OLED_ClockHigh();
    Timing_DelayUs(5u);
    ack = (uint8_t)(ack && !GPIO_ReadInputDataBit(GPIOB, OLED_SDA_PIN));
    OLED_SCL_LOW();
#if OLED_PUSH_PULL
    OLED_SDA_HIGH();
    gpio.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOB, &gpio);
#endif
    if (!ack && !oled_error) oled_error = 1u;
    return ack;
}

static uint8_t OLED_Command(uint8_t command)
{
    uint8_t ok = OLED_I2C_Start();
    if (ok) ok = OLED_I2C_SendByte(OLED_ADDRESS_WRITE);
    if (ok) ok = OLED_I2C_SendByte(0x00u);
    if (ok) ok = OLED_I2C_SendByte(command);
    OLED_I2C_Stop();
    return ok;
}

static uint8_t OLED_SetPage(uint8_t page)
{
    return (uint8_t)(OLED_Command((uint8_t)(0xB0u | page)) &&
                     OLED_Command(0x10u) && OLED_Command(0x00u));
}

void OLED_Clear(void)
{
    uint16_t i;
    for (i = 0u; i < sizeof(screen); ++i) screen[i] = 0u;
}

void OLED_Update(void)
{
    uint8_t page, column, ok;
    oled_error = 0u;
    for (page = 0u; page < 8u; ++page)
    {
        if (!OLED_SetPage(page)) return;
        ok = OLED_I2C_Start();
        if (ok) ok = OLED_I2C_SendByte(OLED_ADDRESS_WRITE);
        if (ok) ok = OLED_I2C_SendByte(0x40u);
        for (column = 0u; ok && column < OLED_WIDTH; ++column)
            ok = OLED_I2C_SendByte(screen[(uint16_t)page * OLED_WIDTH + column]);
        OLED_I2C_Stop();
        if (!ok) return;
    }
}

void OLED_DrawPixel(uint8_t x, uint8_t y)
{
    if ((x < OLED_WIDTH) && (y < OLED_HEIGHT))
    {
        screen[(uint16_t)(y >> 3) * OLED_WIDTH + x] |= (uint8_t)(1u << (y & 7u));
    }
}

void OLED_DrawLine(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1)
{
    int x = x0;
    int y = y0;
    int dx = x1 > x0 ? x1 - x0 : x0 - x1;
    int dy = y1 > y0 ? y1 - y0 : y0 - y1;
    int sx = x0 < x1 ? 1 : -1;
    int sy = y0 < y1 ? 1 : -1;
    int error = dx - dy;
    int twice_error;

    for (;;)
    {
        OLED_DrawPixel((uint8_t)x, (uint8_t)y);
        if ((x == x1) && (y == y1)) break;
        twice_error = 2 * error;
        if (twice_error > -dy)
        {
            error -= dy;
            x += sx;
        }
        if (twice_error < dx)
        {
            error += dx;
            y += sy;
        }
    }
}

void OLED_ShowChar(uint8_t line, uint8_t column, char character)
{
    uint8_t i;
    uint8_t page;
    uint8_t x;
    uint8_t font_index;

    if ((line < 1u) || (line > 4u) || (column < 1u) || (column > 16u)) return;
    if ((character < ' ') || (character > '~')) character = ' ';
    font_index = (uint8_t)(character - ' ');
    page = (uint8_t)((line - 1u) * 2u);
    x = (uint8_t)((column - 1u) * 8u);

    for (i = 0u; i < 8u; i++)
    {
        screen[(uint16_t)page * OLED_WIDTH + x + i] = OLED_F8x16[font_index][i];
        screen[(uint16_t)(page + 1u) * OLED_WIDTH + x + i] =
            OLED_F8x16[font_index][i + 8u];
    }
}

void OLED_ShowString(uint8_t line, uint8_t column, char *string)
{
    while ((*string != '\0') && (column <= 16u))
    {
        OLED_ShowChar(line, column, *string);
        string++;
        column++;
    }
}

static void OLED_ShowUnsignedBase(uint8_t line, uint8_t column,
                                  uint32_t number, uint8_t length, uint8_t base)
{
    char digits[11];
    uint8_t i;
    uint8_t digit;

    if (length > 10u) length = 10u;
    for (i = 0u; i < length; i++)
    {
        digit = (uint8_t)(number % base);
        digits[length - i - 1u] = digit < 10u ?
                                  (char)('0' + digit) : (char)('A' + digit - 10u);
        number /= base;
    }
    digits[length] = '\0';
    OLED_ShowString(line, column, digits);
}

void OLED_ShowNum(uint8_t line, uint8_t column, uint32_t number, uint8_t length)
{
    OLED_ShowUnsignedBase(line, column, number, length, 10u);
}

void OLED_ShowSignedNum(uint8_t line, uint8_t column, int32_t number, uint8_t length)
{
    uint32_t magnitude;

    OLED_ShowChar(line, column, number < 0 ? '-' : '+');
    magnitude = number < 0 ? (uint32_t)(-(number + 1)) + 1u : (uint32_t)number;
    OLED_ShowUnsignedBase(line, (uint8_t)(column + 1u), magnitude, length, 10u);
}

void OLED_ShowHexNum(uint8_t line, uint8_t column, uint32_t number, uint8_t length)
{
    OLED_ShowUnsignedBase(line, column, number, length, 16u);
}

void OLED_ShowBinNum(uint8_t line, uint8_t column, uint32_t number, uint8_t length)
{
    OLED_ShowUnsignedBase(line, column, number, length, 2u);
}

void OLED_Init(void)
{
    GPIO_InitTypeDef gpio;
    static const uint8_t commands[] = {
        0xAE, 0xD5, 0x80, 0xA8, 0x3F, 0xD3, 0x00, 0x40,
        0xA1, 0xC8, 0xDA, 0x12, 0x81, 0xCF, 0xD9, 0xF1,
        0xDB, 0x30, 0xA4, 0xA6, 0x8D, 0x14, 0xAF
    };
    uint8_t i;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    gpio.GPIO_Pin = OLED_SCL_PIN | OLED_SDA_PIN;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    gpio.GPIO_Mode = OLED_PUSH_PULL ? GPIO_Mode_Out_PP : GPIO_Mode_Out_OD;
    GPIO_Init(GPIOB, &gpio);
    OLED_SCL_HIGH();
    OLED_SDA_HIGH();

    Timing_Init();
    Timing_DelayUs(100000u);
    for (i = 0u; i < sizeof(commands); i++) OLED_Command(commands[i]);
    OLED_Clear();
    OLED_Update();
}

#ifndef APP_H
#define APP_H

void App_Init(void);
void App_Loop(void);
void App_SysTickIRQ(void);
void App_DMA1Channel1IRQ(void);

#endif

#ifndef APP_CONFIG_H
#define APP_CONFIG_H

/* Our inverting front end: Vadc = 1.642534 - 0.294118 * Vin.
 * Baseline scale for AC/WAVE; AC amplitude calibration is still pending. */
#define CAL_ZERO_COUNTS        2038.2353f
#define CAL_COUNTS_PER_VOLT     364.9733f

/* Provisional DC-only calibration, 2026-10-31, third confirmed sweep.
 * Organizer signal generator; fit only the eight points from 0 to 3.5 V.
 * V2.4 = 0.999143591208 * V2.3 + 0.012632029689.
 * Fitted maximum residual 1.641450 mV is not measured accuracy.
 * Earlier batches are not included; existing V2.3 conversion is inverted
 * only to reconstruct ADC means from the rounded third-batch displays.
 * High-end compression, negative inputs and >3.5 V remain unvalidated. */
#define DC_CAL_ZERO_COUNTS     2044.3760329691f
#define DC_CAL_COUNTS_PER_VOLT  373.6592230266f
#define DC_CAL_VALID_MIN_V      0.0f
#define DC_CAL_VALID_MAX_V      3.5f
/* Warning margin avoids flicker at endpoints; it does not extend calibration. */
#define DC_CAL_WARNING_MARGIN_V 0.020f

/* V2.5, fourth sweep: local high-end DC branch only.
 * Preserve the V2.4 result through 3.9 V; blend continuously to 4.0 V.
 * Counts are rounded display observations, not exact ADC means.
 * Returning 4.9/5.0 V observations overlap the lower branch and are NOT fitted. */
#define DC_HIGH_BLEND_START_V    3.9f
#define DC_HIGH_LAST_COUNTS      267.0f
#define DC_HIGH_END_MARGIN       0.5f
#define DC_HIGH_AMBIG_COUNTS     380.0f

#define ADC_BUFFER_LENGTH       2048u
#define SAMPLE_RATE_DC          51200u
#define SAMPLE_RATE_SLOW        50000u
#define SAMPLE_RATE_FAST        500000u
#define BUTTON_DEBOUNCE_MS      20u
#define DISPLAY_PERIOD_MS       120u
#define CAPTURE_TIMEOUT_MS      250u
#define SIGNAL_MIN_SPAN         12u

/* Keep the F-drive project's PB7/PB8 push-pull configuration after checking the core-board pinout.
 * SDA is switched to input during ACK. Set 0 for open drain when both
 * lines have suitable pull-ups to 3.3 V. Do not copy the peer's pin map. */
/* Existing PCB: U7-5 -> PB8 -> SDA, U7-6 -> PB7 -> SCL.
 * U7-7 is PB6 and is not used by the existing OLED traces. */
#define OLED_SCL_PIN           GPIO_Pin_7
#define OLED_SDA_PIN           GPIO_Pin_8
#define OLED_PUSH_PULL          1
#define OLED_ADDRESS_WRITE      0x78u

#endif

#include "stm32f10x.h"
#include "OLED.h"
#include "app.h"
#include "app_config.h"
#include "signal.h"
#include "timing.h"
#include <stdio.h>

typedef enum { MODE_DC = 0, MODE_AC = 1, MODE_WAVE = 2 } AppMode;
static volatile uint16_t adc_buffer[ADC_BUFFER_LENGTH];
static volatile uint8_t capture_done;
static volatile uint8_t button_event;
static volatile uint32_t tick_ms;
static uint8_t button_sample = 1u, button_stable = 1u, button_count;
static uint32_t timer_clock_hz, capture_rate_hz, capture_started_ms;
static uint32_t next_capture_ms, next_capture_rate = SAMPLE_RATE_DC;
static AppMode mode = MODE_DC;
static uint8_t precision_pass, capture_active;
static float frequency_history[3];
static uint8_t frequency_count, frequency_index;
static float wave_low, wave_high;
static uint8_t wave_range_valid;

static void Unused_GPIO_Init(void)
{
    GPIO_InitTypeDef gpio;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB, ENABLE);
    gpio.GPIO_Speed = GPIO_Speed_2MHz;
    gpio.GPIO_Mode = GPIO_Mode_AIN;

    /* Leave PA0 (ADC), PA1 (button), PA11/PA12 (board USB), and
     * PA13/PA14/PA15 (SWD/JTAG) untouched. */
    gpio.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 |
                    GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7 |
                    GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10;
    GPIO_Init(GPIOA, &gpio);

    /* Preserve BOOT1/JTAG and the configured OLED pins (now PB7/PB8). */
    gpio.GPIO_Pin = (GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_5 |
                     GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 |
                     GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13 |
                     GPIO_Pin_14 | GPIO_Pin_15) & ~(OLED_SCL_PIN | OLED_SDA_PIN);
    GPIO_Init(GPIOB, &gpio);

    /* PC13 is connected to the board LED; PC14/PC15 are reserved for LSE. */
}

static void Button_Init(void)
{
    GPIO_InitTypeDef gpio;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    gpio.GPIO_Pin = GPIO_Pin_1;
    gpio.GPIO_Speed = GPIO_Speed_2MHz;
    gpio.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOA, &gpio);
}

static uint8_t Button_Pressed(void)
{
    uint8_t pressed;

    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    pressed = button_event;
    button_event = 0u;
    __set_PRIMASK(primask);
    return pressed;
}

static void ADC_Timer_DMA_Init(void)
{
    GPIO_InitTypeDef gpio;
    ADC_InitTypeDef adc;
    DMA_InitTypeDef dma;
    TIM_TimeBaseInitTypeDef timer;
    NVIC_InitTypeDef nvic;
    RCC_ClocksTypeDef clocks;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_ADC1, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
    RCC_ADCCLKConfig(RCC_PCLK2_Div6); /* 72 MHz system: 12 MHz ADC clock. */

    gpio.GPIO_Pin = GPIO_Pin_0;
    gpio.GPIO_Speed = GPIO_Speed_50MHz;
    gpio.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOA, &gpio);

    RCC_GetClocksFreq(&clocks);
    timer_clock_hz = clocks.PCLK1_Frequency;
    if (clocks.PCLK1_Frequency != clocks.HCLK_Frequency)
    {
        timer_clock_hz *= 2u;
    }

    TIM_TimeBaseStructInit(&timer);
    timer.TIM_Prescaler = 0u;
    timer.TIM_Period = (uint16_t)(timer_clock_hz / SAMPLE_RATE_SLOW - 1u);
    timer.TIM_ClockDivision = TIM_CKD_DIV1;
    timer.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM3, &timer);
    TIM_SelectOutputTrigger(TIM3, TIM_TRGOSource_Update);
    TIM_ARRPreloadConfig(TIM3, DISABLE);
    TIM_Cmd(TIM3, DISABLE);

    DMA_DeInit(DMA1_Channel1);
    dma.DMA_PeripheralBaseAddr = (uint32_t)&ADC1->DR;
    dma.DMA_MemoryBaseAddr = (uint32_t)adc_buffer;
    dma.DMA_DIR = DMA_DIR_PeripheralSRC;
    dma.DMA_BufferSize = ADC_BUFFER_LENGTH;
    dma.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    dma.DMA_MemoryInc = DMA_MemoryInc_Enable;
    dma.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
    dma.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
    dma.DMA_Mode = DMA_Mode_Normal;
    dma.DMA_Priority = DMA_Priority_High;
    dma.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel1, &dma);
    DMA_ITConfig(DMA1_Channel1, DMA_IT_TC | DMA_IT_TE, ENABLE);

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    nvic.NVIC_IRQChannel = DMA1_Channel1_IRQn;
    nvic.NVIC_IRQChannelPreemptionPriority = 1u;
    nvic.NVIC_IRQChannelSubPriority = 0u;
    nvic.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&nvic);

    ADC_DeInit(ADC1);
    ADC_StructInit(&adc);
    adc.ADC_Mode = ADC_Mode_Independent;
    adc.ADC_ScanConvMode = DISABLE;
    adc.ADC_ContinuousConvMode = DISABLE;
    adc.ADC_ExternalTrigConv = ADC_ExternalTrigConv_T3_TRGO;
    adc.ADC_DataAlign = ADC_DataAlign_Right;
    adc.ADC_NbrOfChannel = 1u;
    ADC_Init(ADC1, &adc);
    ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 1u, ADC_SampleTime_28Cycles5);
    ADC_DMACmd(ADC1, ENABLE);
    ADC_Cmd(ADC1, ENABLE);
    Timing_DelayUs(2u);
    ADC_ResetCalibration(ADC1);
    while (ADC_GetResetCalibrationStatus(ADC1) != RESET) { }
    ADC_StartCalibration(ADC1);
    while (ADC_GetCalibrationStatus(ADC1) != RESET) { }
    ADC_ExternalTrigConvCmd(ADC1, ENABLE);
}

static void Capture_Stop(void)
{
    uint32_t primask = __get_PRIMASK();
    __disable_irq();
    TIM_Cmd(TIM3, DISABLE);
    ADC_ExternalTrigConvCmd(ADC1, DISABLE);
    ADC_Cmd(ADC1, DISABLE);
    DMA_Cmd(DMA1_Channel1, DISABLE);
    DMA_ClearITPendingBit(DMA1_IT_GL1);
    NVIC_ClearPendingIRQ(DMA1_Channel1_IRQn);
    capture_done = 0u;
    __set_PRIMASK(primask);
}

static void Capture_Start(uint32_t requested_rate)
{
    uint32_t divisor;
    Capture_Stop();
    if (requested_rate < SAMPLE_RATE_SLOW) requested_rate = SAMPLE_RATE_SLOW;
    if (requested_rate > SAMPLE_RATE_FAST) requested_rate = SAMPLE_RATE_FAST;
    divisor = (timer_clock_hz + requested_rate / 2u) / requested_rate;
    capture_rate_hz = (timer_clock_hz + divisor / 2u) / divisor;
    ADC_RegularChannelConfig(ADC1, ADC_Channel_0, 1u,
        capture_rate_hz <= 200000u ? ADC_SampleTime_28Cycles5 : ADC_SampleTime_7Cycles5);
    TIM_SetAutoreload(TIM3, (uint16_t)(divisor - 1u));
    TIM_GenerateEvent(TIM3, TIM_EventSource_Update);
    TIM_SetCounter(TIM3, 0u);
    TIM_ClearFlag(TIM3, TIM_FLAG_Update);
    ADC_ClearFlag(ADC1, ADC_FLAG_EOC | ADC_FLAG_STRT);
    DMA_SetCurrDataCounter(DMA1_Channel1, ADC_BUFFER_LENGTH);
    ADC_Cmd(ADC1, ENABLE);
    Timing_DelayUs(2u);
    DMA_Cmd(DMA1_Channel1, ENABLE);
    ADC_ExternalTrigConvCmd(ADC1, ENABLE);
    capture_started_ms = tick_ms;
    capture_active = 1u;
    TIM_Cmd(TIM3, ENABLE);
}

static void ResetDisplayHistory(void)
{
    frequency_count = frequency_index = 0u;
    wave_range_valid = 0u;
}

static float StableFrequency(float frequency)
{
    float a, b, c, t;
    if (frequency <= 0.0f)
    {
        frequency_count = 0u;
        return 0.0f;
    }
    /* A substantial real frequency change must not wait on old history. */
    if (frequency_count != 0u)
    {
        float last = frequency_history[(frequency_index + 2u) % 3u];
        if (frequency < last * 0.85f || frequency > last * 1.15f)
            frequency_count = frequency_index = 0u;
    }
    if (frequency_count == 0u)
    {
        frequency_history[0] = frequency_history[1] = frequency_history[2] = frequency;
        frequency_count = 3u;
    }
    frequency_history[frequency_index] = frequency;
    frequency_index = (uint8_t)((frequency_index + 1u) % 3u);
    a = frequency_history[0]; b = frequency_history[1]; c = frequency_history[2];
    if (a > b) { t = a; a = b; b = t; }
    if (b > c) b = c;
    if (a > b) b = a;
    return b;
}

static void FormatFrequency(char *line, float frequency)
{
    unsigned long hz = (unsigned long)(frequency + 0.5f);
    if (hz >= 1000u)
    {
        unsigned long hundredths = (unsigned long)(frequency / 10.0f + 0.5f);
        sprintf(line, "%lu.%02lukHz", hundredths / 100u, hundredths % 100u);
    }
    else sprintf(line, "%luHz", hz);
}

/* A single-valued correction for the measured lower-input branch.
 * Do not infer a 4.9/5.0 V input from codes also observed at 4.5..4.8 V. */
static float DC_HighCorrect(float mean, float baseline)
{
    static const float knots[][2] = {
        {DC_CAL_ZERO_COUNTS - DC_CAL_COUNTS_PER_VOLT * DC_HIGH_BLEND_START_V,
         DC_HIGH_BLEND_START_V},
        {560.0f, 4.0f}, {523.0f, 4.1f}, {486.0f, 4.2f},
        {449.0f, 4.3f}, {412.0f, 4.4f}, {375.0f, 4.5f},
        {337.0f, 4.6f}, {301.0f, 4.7f}, {267.0f, 4.8f}
    };
    unsigned int i;
    if (baseline <= DC_HIGH_BLEND_START_V ||
        mean < DC_HIGH_LAST_COUNTS - DC_HIGH_END_MARGIN)
        return baseline;
    for (i = 1u; i < sizeof(knots) / sizeof(knots[0]); ++i)
    {
        if (mean >= knots[i][0] || i == sizeof(knots) / sizeof(knots[0]) - 1u)
            return knots[i-1u][1] +
                (knots[i-1u][0] - mean) * (knots[i][1] - knots[i-1u][1]) /
                (knots[i-1u][0] - knots[i][0]);
    }
    return baseline;
}

static void ShowDC(const SignalStats *stats)
{
    char line[24];
    float signed_volts = (DC_CAL_ZERO_COUNTS - stats->mean) / DC_CAL_COUNTS_PER_VOLT;
    float volts = DC_HighCorrect(stats->mean, signed_volts);
    unsigned long mv;
    char sign = volts < 0.0f ? '-' : '+';
    if (volts < 0.0f) volts = -volts;
    mv = (unsigned long)(volts * 1000.0f + 0.5f);
    if (mv == 0u) sign = '+'; /* Avoid a signed zero; do not hide nonzero mV. */
    OLED_Clear();
    OLED_ShowString(1u, 1u, "DC INPUT V2.5");
    sprintf(line, "%c%lu.%03lu V", sign, mv / 1000u, mv % 1000u);
    if (stats->mean < DC_HIGH_LAST_COUNTS - DC_HIGH_END_MARGIN)
        OLED_ShowString(2u, 1u, "OUT OF HIGH CAL");
    else OLED_ShowString(2u, 1u, line);
    sprintf(line, "ADC %lu", (unsigned long)(stats->mean + 0.5f));
    OLED_ShowString(3u, 1u, line);
    if (stats->clipped) OLED_ShowString(4u, 1u, "ADC AT RAIL");
    else if (stats->mean < DC_HIGH_LAST_COUNTS - DC_HIGH_END_MARGIN)
        OLED_ShowString(4u, 1u, "CHECK DC RANGE");
    else if (stats->mean <= DC_HIGH_AMBIG_COUNTS)
        OLED_ShowString(4u, 1u, "HIGH AMBIGUOUS");
    else if (signed_volts > DC_HIGH_BLEND_START_V)
        OLED_ShowString(4u, 1u, "DC HIGH CAL");
    else if (signed_volts < DC_CAL_VALID_MIN_V - DC_CAL_WARNING_MARGIN_V ||
             signed_volts > DC_CAL_VALID_MAX_V + DC_CAL_WARNING_MARGIN_V)
        OLED_ShowString(4u, 1u, "CHECK DC RANGE");
    else OLED_ShowString(4u, 1u, "DC CAL 0-3.5V");
    OLED_Update();
}

static void ShowAC(const SignalStats *stats)
{
    char line[24], freq_line[16];
    float frequency = StableFrequency(stats->frequency);
    unsigned long mv = (unsigned long)(2.8284271f * stats->rms /
                                      CAL_COUNTS_PER_VOLT * 1000.0f + 0.5f);
    OLED_Clear();
    OLED_ShowString(1u, 1u, "AC SINE V2.3");
    if (stats->valid != 0u)
    {
        sprintf(line, "VPP %lu.%03lu V", mv / 1000u, mv % 1000u);
        OLED_ShowString(2u, 1u, line);
        FormatFrequency(freq_line, frequency);
        sprintf(line, "F %s", freq_line);
        OLED_ShowString(3u, 1u, line);
        if (stats->clipped) OLED_ShowString(4u, 1u, "ADC AT RAIL");
    }
    else OLED_ShowString(2u, 1u, "NO STABLE SIGNAL");
    OLED_Update();
}

static uint8_t WaveY(float value)
{
    float y = 2.0f + (value - wave_low) * 42.0f / (wave_high - wave_low);
    if (y < 1.0f) y = 1.0f;
    if (y > 45.0f) y = 45.0f;
    return (uint8_t)(y + 0.5f);
}

static void ShowWave(const SignalStats *stats)
{
    char line[24], freq_line[16];
    uint8_t x, previous_y = 0u;
    unsigned long mv;
    float frequency = StableFrequency(stats->frequency);
    OLED_Clear();
    if (stats->valid != 0u && stats->maximum > stats->minimum)
    {
        float period = (float)capture_rate_hz / stats->frequency;
        float span = period * 2.0f;
        float start = stats->first_crossing;
        float pad = (float)(stats->maximum - stats->minimum) * 0.05f;
        float wanted_low = (float)stats->minimum - pad;
        float wanted_high = (float)stats->maximum + pad;
        if (!wave_range_valid)
        {
            wave_low = wanted_low;
            wave_high = wanted_high;
            wave_range_valid = 1u;
        }
        else
        {
            /* Expand immediately, contract gently, without clipping a new peak. */
            wave_low = wanted_low < wave_low ? wanted_low :
                       wave_low + (wanted_low - wave_low) * 0.125f;
            wave_high = wanted_high > wave_high ? wanted_high :
                        wave_high + (wanted_high - wave_high) * 0.125f;
        }
        if (span > (float)(ADC_BUFFER_LENGTH - 2u)) span = (float)(ADC_BUFFER_LENGTH - 2u);
        if (start + span > (float)(ADC_BUFFER_LENGTH - 2u)) start = 0.0f;
        for (x = 0u; x < 128u; ++x)
        {
            float position = start + span * (float)x / 127.0f;
            float next = start + span * (float)(x + 1u) / 127.0f;
            uint32_t index = (uint32_t)position;
            uint32_t last = (uint32_t)next;
            float fraction = position - (float)index;
            float value;
            uint8_t y;
            if (index >= ADC_BUFFER_LENGTH - 1u) index = ADC_BUFFER_LENGTH - 2u;
            value = (float)adc_buffer[index] * (1.0f - fraction) +
                    (float)adc_buffer[index + 1u] * fraction;
            y = WaveY(value); /* Our analogue input polarity is inverted. */
            if (x == 0u) OLED_DrawPixel(x, y);
            else OLED_DrawLine((uint8_t)(x - 1u), previous_y, x, y);
            previous_y = y;
            /* When reducing many samples to one pixel, retain the envelope.
             * Thus a narrow pulse between display columns remains visible. */
            if (span > 127.0f)
            {
                uint16_t mn = adc_buffer[index], mx = mn;
                uint32_t i;
                if (last >= ADC_BUFFER_LENGTH) last = ADC_BUFFER_LENGTH - 1u;
                for (i = index; i <= last; ++i)
                {
                    if (adc_buffer[i] < mn) mn = adc_buffer[i];
                    if (adc_buffer[i] > mx) mx = adc_buffer[i];
                }
                OLED_DrawLine(x, WaveY((float)mn), x, WaveY((float)mx));
            }
        }
        mv = (unsigned long)((float)(stats->maximum - stats->minimum) /
                             CAL_COUNTS_PER_VOLT * 1000.0f + 0.5f);
        FormatFrequency(freq_line, frequency);
        sprintf(line, "%lu.%03luV %s", mv / 1000u, mv % 1000u, freq_line);
        OLED_ShowString(4u, 1u, line);
        if (stats->clipped) OLED_ShowString(1u, 1u, "ADC AT RAIL");
    }
    else
    {
        wave_range_valid = 0u;
        OLED_ShowString(2u, 1u, "NO STABLE SIGNAL");
    }
    OLED_Update();
}

static uint32_t WaveSampleRate(float frequency)
{
    uint32_t rate = (uint32_t)(frequency * 64.0f + 0.5f);
    if (rate < SAMPLE_RATE_SLOW) rate = SAMPLE_RATE_SLOW;
    if (rate > SAMPLE_RATE_FAST) rate = SAMPLE_RATE_FAST;
    return rate;
}

void App_Init(void)
{
    SystemCoreClockUpdate();
    Timing_Init();
    Unused_GPIO_Init();
    Button_Init();
    SysTick_Config(SystemCoreClock / 1000u);
    OLED_Init();
    ADC_Timer_DMA_Init();
    Capture_Start(SAMPLE_RATE_DC);
}

static void AdvanceMode(void)
{
    mode = (AppMode)(((uint8_t)mode + 1u) % 3u);
    precision_pass = 0u;
    ResetDisplayHistory();
    /* Remove the previous mode's frame before the first new measurement. */
    OLED_Clear();
    OLED_ShowString(1u, 1u, mode == MODE_DC ? "DC INPUT V2.5" :
                           mode == MODE_AC ? "AC SINE V2.3" : "WAVE V2.3");
    OLED_ShowString(2u, 1u, "SAMPLING...");
    Capture_Stop();
    OLED_Update();
    Capture_Start(mode == MODE_DC ? SAMPLE_RATE_DC : SAMPLE_RATE_SLOW);
}

void App_Loop(void)
{
    SignalStats stats;
    uint8_t status;
    uint32_t rate;
    if (Button_Pressed())
    {
        AdvanceMode();
        return;
    }
    if (!capture_active)
    {
        if ((int32_t)(tick_ms - next_capture_ms) >= 0)
            Capture_Start(next_capture_rate);
        return;
    }
    status = capture_done;
    if (status == 0u && (uint32_t)(tick_ms - capture_started_ms) <= CAPTURE_TIMEOUT_MS) return;
    capture_active = 0u;
    if (status != 1u)
    {
        Capture_Stop();
        ResetDisplayHistory();
        precision_pass = 0u;
        OLED_Clear();
        OLED_ShowString(2u, 1u, status == 2u ? "ADC DMA ERROR" : "ADC TIMEOUT");
        OLED_Update();
        next_capture_ms = tick_ms + 200u;
        next_capture_rate = mode == MODE_DC ? SAMPLE_RATE_DC : SAMPLE_RATE_SLOW;
        return;
    }
    capture_done = 0u;
    /* DMA and timer are stopped by the ISR before processing this buffer. */
    Signal_Analyse((uint16_t *)adc_buffer, ADC_BUFFER_LENGTH, capture_rate_hz, &stats);
    if (Button_Pressed())
    {
        AdvanceMode();
        return;
    }
    if (mode != MODE_DC && stats.valid && precision_pass == 0u)
    {
        rate = mode == MODE_AC && stats.frequency > 1500.0f ? SAMPLE_RATE_FAST :
               mode == MODE_WAVE ? WaveSampleRate(stats.frequency) : capture_rate_hz;
        if (rate > capture_rate_hz + capture_rate_hz / 10u ||
            rate + rate / 3u < capture_rate_hz)
        {
            precision_pass = 1u;
            Capture_Start(rate);
            return;
        }
    }
    if (mode == MODE_DC) ShowDC(&stats);
    else if (mode == MODE_AC) ShowAC(&stats);
    else ShowWave(&stats);
    precision_pass = 0u;
    next_capture_rate = mode == MODE_DC ? SAMPLE_RATE_DC :
                        mode == MODE_WAVE && stats.valid ? WaveSampleRate(stats.frequency) : SAMPLE_RATE_SLOW;
    next_capture_ms = capture_started_ms + DISPLAY_PERIOD_MS;
}

void App_SysTickIRQ(void)
{
    uint8_t raw;
    ++tick_ms;
    raw = (uint8_t)GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1);
    if (raw != button_sample)
    {
        button_sample = raw;
        button_count = 0u;
    }
    else if (button_count < BUTTON_DEBOUNCE_MS) ++button_count;
    if (button_count >= BUTTON_DEBOUNCE_MS && raw != button_stable)
    {
        button_stable = raw;
        if (raw == 0u) button_event = 1u;
    }
}

void App_DMA1Channel1IRQ(void)
{
    if (DMA_GetITStatus(DMA1_IT_TE1) != RESET)
    {
        TIM_Cmd(TIM3, DISABLE);
        ADC_ExternalTrigConvCmd(ADC1, DISABLE);
        DMA_Cmd(DMA1_Channel1, DISABLE);
        DMA_ClearITPendingBit(DMA1_IT_GL1);
        capture_done = 2u;
    }
    else if (DMA_GetITStatus(DMA1_IT_TC1) != RESET)
    {
        TIM_Cmd(TIM3, DISABLE);
        ADC_ExternalTrigConvCmd(ADC1, DISABLE);
        DMA_Cmd(DMA1_Channel1, DISABLE);
        DMA_ClearITPendingBit(DMA1_IT_GL1);
        capture_done = 1u;
    }
}

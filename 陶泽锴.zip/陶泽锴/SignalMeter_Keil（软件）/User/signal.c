#include "signal.h"
#include "app_config.h"

static uint16_t histogram[256];

static float Root(float value)
{
    float estimate;
    uint8_t i;
    if (value <= 0.0f) return 0.0f;
    estimate = value > 1.0f ? value : 1.0f;
    for (i = 0u; i < 18u; ++i)
        estimate = 0.5f * (estimate + value / estimate);
    return estimate;
}

static uint16_t RemoveSpikes(uint16_t *a, uint32_t n)
{
    uint32_t i, tail, sum, low_bin, high_bin;
    uint32_t count = 0u, positions[2];
    int32_t low, high, margin, neighbour_limit, difference;
    for (i = 0u; i < 256u; ++i) histogram[i] = 0u;
    for (i = 0u; i < n; ++i) ++histogram[a[i] >> 4];
    tail = n / 100u;
    if (tail < 1u) tail = 1u;
    sum = 0u;
    for (low_bin = 0u; low_bin < 255u; ++low_bin)
    {
        sum += histogram[low_bin];
        if (sum >= tail) break;
    }
    sum = 0u;
    for (high_bin = 255u; high_bin > 0u; --high_bin)
    {
        sum += histogram[high_bin];
        if (sum >= tail) break;
    }
    low = (int32_t)(low_bin * 16u);
    high = (int32_t)(high_bin * 16u + 15u);
    margin = (high - low) / 4;
    if (margin < 8) margin = 8;
    neighbour_limit = (high - low) / 8;
    if (neighbour_limit < 6) neighbour_limit = 6;
    /* First count all out-of-band samples. If a narrow pulse repeats,
     * its samples are not mistaken for a small number of ADC glitches. */
    for (i = 0u; i < n; ++i)
    {
        if ((int32_t)a[i] < low - margin || (int32_t)a[i] > high + margin)
        {
            if (count >= 2u) return 0u;
            positions[count++] = i;
        }
    }
    sum = 0u;
    for (i = 0u; i < count; ++i)
    {
        uint32_t p = positions[i];
        if (p == 0u || p + 1u >= n) continue;
        difference = (int32_t)a[p - 1u] - (int32_t)a[p + 1u];
        if (difference < 0) difference = -difference;
        if (difference <= neighbour_limit)
        {
            a[p] = (uint16_t)(((uint32_t)a[p - 1u] + a[p + 1u]) / 2u);
            ++sum;
        }
    }
    return (uint16_t)sum;
}

void Signal_Analyse(uint16_t *a, uint32_t n,
                    uint32_t sample_rate, SignalStats *r)
{
    uint32_t i, total = 0u, begin = 0u, end = n;
    float mid, low, high, h, cross = 0.0f, previous = 0.0f;
    float min_period = 1.0e20f, max_period = 0.0f;
    float mean, variance = 0.0f, average_period;
    uint8_t armed = 0u, pending = 0u;
    r->mean = r->rms = r->frequency = 0.0f;
    r->first_crossing = r->last_crossing = 0.0f;
    r->minimum = r->maximum = r->crossings = r->removed_spikes = 0u;
    r->valid = r->clipped = 0u;
    if (n < 4u || n > ADC_BUFFER_LENGTH || sample_rate == 0u) return;
    /* Guard the histogram against corrupt/out-of-range input codes. */
    for (i = 0u; i < n; ++i) if (a[i] > 4095u) return;
    r->removed_spikes = RemoveSpikes(a, n);
    r->minimum = 4095u;
    for (i = 0u; i < n; ++i)
    {
        total += a[i];
        if (a[i] < r->minimum) r->minimum = a[i];
        if (a[i] > r->maximum) r->maximum = a[i];
    }
    r->mean = (float)total / (float)n;
    r->clipped = (uint8_t)(r->minimum <= 2u || r->maximum >= 4093u);
    mid = ((float)r->minimum + (float)r->maximum) * 0.5f;
    h = (float)(r->maximum - r->minimum) * 0.125f;
    if (h < 2.0f) h = 2.0f;
    low = mid - h;
    high = mid + h;

    /* ADC falling edge means external-input rising edge on our board.
     * Arm at the high threshold, interpolate the midpoint crossing, and
     * confirm at the low threshold. Midpoint is independent of duty cycle. */
    if (r->maximum - r->minimum >= SIGNAL_MIN_SPAN)
    {
        for (i = 1u; i < n; ++i)
        {
            float value = (float)a[i];
            if ((float)a[i - 1u] >= high) armed = 1u;
            if (armed != 0u)
            {
                if ((float)a[i - 1u] > mid && value <= mid)
                {
                    cross = (float)(i - 1u) +
                            ((float)a[i - 1u] - mid) /
                            ((float)a[i - 1u] - value);
                    pending = 1u;
                }
                if (value > mid) pending = 0u;
                if (pending != 0u && value <= low)
                {
                    if (r->crossings == 0u) r->first_crossing = cross;
                    else
                    {
                        float interval = cross - previous;
                        if (interval < min_period) min_period = interval;
                        if (interval > max_period) max_period = interval;
                    }
                    previous = cross;
                    r->last_crossing = cross;
                    ++r->crossings;
                    armed = pending = 0u;
                }
            }
        }
    }
    if (r->crossings >= 2u && r->last_crossing > r->first_crossing)
    {
        average_period = (r->last_crossing - r->first_crossing) /
                         (float)(r->crossings - 1u);
        /* Reject irregular noise crossings. A single measured period has
         * lower confidence; retain it for low frequencies/short records. */
        if (min_period >= average_period * 0.65f &&
            max_period <= average_period * 1.35f)
        {
            r->frequency = (float)sample_rate / average_period;
            r->valid = 1u;
            begin = (uint32_t)(r->first_crossing + 0.5f);
            end = (uint32_t)(r->last_crossing + 0.5f);
        }
    }
    /* RMS over approximately whole periods avoids fractional-cycle bias.
     * Keep mean above as the full-record DC reading. */
    total = 0u;
    for (i = begin; i < end; ++i) total += a[i];
    mean = (float)total / (float)(end - begin);
    for (i = begin; i < end; ++i)
    {
        float d = (float)a[i] - mean;
        variance += d * d;
    }
    r->rms = Root(variance / (float)(end - begin));
}

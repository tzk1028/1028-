#include "stm32f10x.h"
#include "timing.h"

/* This project's older CMSIS header omits the Cortex-M3 DWT definition. */
#define TIMING_DWT_CTRL   (*(volatile uint32_t *)0xE0001000u)
#define TIMING_DWT_CYCCNT (*(volatile uint32_t *)0xE0001004u)

void Timing_Init(void)
{
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    TIMING_DWT_CTRL |= 1u;
}

void Timing_DelayUs(uint32_t microseconds)
{
    uint32_t start = TIMING_DWT_CYCCNT;
    uint32_t ticks = (SystemCoreClock / 1000000u) * microseconds;
    while ((uint32_t)(TIMING_DWT_CYCCNT - start) < ticks) { }
}

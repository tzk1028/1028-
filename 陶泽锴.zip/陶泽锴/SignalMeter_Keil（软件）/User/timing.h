#ifndef TIMING_H
#define TIMING_H
#include <stdint.h>
void Timing_Init(void);
void Timing_DelayUs(uint32_t microseconds);
#endif

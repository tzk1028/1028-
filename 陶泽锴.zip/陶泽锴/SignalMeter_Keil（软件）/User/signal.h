#ifndef SIGNAL_H
#define SIGNAL_H
#include <stdint.h>

typedef struct
{
    float mean;
    float rms;
    float frequency;
    float first_crossing;
    float last_crossing;
    uint16_t minimum;
    uint16_t maximum;
    uint16_t crossings;
    uint16_t removed_spikes;
    uint8_t valid;
    uint8_t clipped;
} SignalStats;

/* Edits at most two isolated out-of-band spikes. Repeated narrow pulses
 * are retained; there is no unconditional median filter on the waveform. */
void Signal_Analyse(uint16_t *samples, uint32_t length,
                    uint32_t sample_rate, SignalStats *result);
#endif
